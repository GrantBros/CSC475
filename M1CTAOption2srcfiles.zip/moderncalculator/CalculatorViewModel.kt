package com.example.moderncalculator

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.roundToLong

class CalculatorViewModel : ViewModel() {
    //legwork for application functionality and displays. sends values of button execution as strings to device screen
    private val _uiState = MutableStateFlow(CalculatorState())
    val uiState = _uiState.asStateFlow()

    fun onDigit(digit: String) {
        //setting values to default 0 when starting and clearing with "C" button click
        val state = _uiState.value

        val newDisplay = when {
            state.clearOnNextDigit -> digit
            state.display == "0" -> digit
            else -> state.display + digit
        }
        _uiState.value = state.copy(
            display = newDisplay,
            clearOnNextDigit = false
        )
    }
    fun onDecimal() {
        //allows for display of decimal string concatenated to previous and future input while checking for previous decimal usage
        val state = uiState.value
        if (!state.display.contains(".")) {
            _uiState.value = state.copy(display = state.display + ".")
        }
    }
    fun onOperation(op: Operation) {
        //use Elvis operator to determine need for operation then clearing
        //Also overwrites pre-existing operation, intended so last clicked operation is used
        val state = _uiState.value

        val newOperand = state.display.toDoubleOrNull() ?: 0.0
        _uiState.value = state.copy(
            operand = newOperand,
            pendingOperation = op,
            clearOnNextDigit = true
        )
    }
    fun onEquals() {
        //Elvis operator aging to determine if equals operation is valid
        val state = _uiState.value
        val operand1 = state.operand ?: return
        val operand2 = state.display.toDoubleOrNull() ?: return

        val result = when (state.pendingOperation) {
            //function that determines Operation assignment and actions
            Operation.Add -> operand1 + operand2
            Operation.Subtract -> operand1 - operand2
            Operation.Multiply -> operand1 * operand2
            Operation.Divide -> {
                //divide by zero handling
                if (operand2 == 0.0) {
                    _uiState.value = state.copy(display = "Error")
                    return
                } else {
                    operand1 / operand2
                }
            }
            null -> operand2
        }
        //checking for infinite and non-number results and throws errors instead of crashing
        val formatted = if (!result.isFinite()) {
            "Error"
        } else if (result % 1 == 0.0) {
            result.roundToLong().toString()
        } else {
            result.toString()
        }
        _uiState.value = CalculatorState(display = formatted)
    }
    fun onClear() {
        _uiState.value = CalculatorState()
    }
}