package com.example.moderncalculator.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.moderncalculator.*
import androidx.compose.foundation.background

//this file determines physical location and appearance of buttons and their content such as strings and actions
//In the learning material the author used .xml design option to navigate and assignment these values but CTA required kotlin usage due to Jetpack Compose
@Composable
fun CalculatorScreen(
    state: CalculatorState,
    onDigit: (String) -> Unit,
    onDecimal: () -> Unit,
    onOperation: (Operation) -> Unit,
    onEquals: () -> Unit,
    onClear: () -> Unit
) {
    //simple column and row placements with clicking display based on operator type i.e. divide, multiply, etc..
    Column(
        modifier = Modifier
            .fillMaxSize()
            //custom dark-mode additions
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            //added custom dark-mode calls because default seemed too similar
            text = state.display,
            color = MaterialTheme.colorScheme.onBackground,
            style = MaterialTheme.typography.displayLarge,
            fontSize = 48.sp,
            lineHeight = 56.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.End,
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(bottom = 16.dp)
        )

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CalcButton("C", Modifier.weight(1f)) { onClear() }
                CalcButton("÷", Modifier.weight(1f)) { onOperation(Operation.Divide) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CalcButton("7", Modifier.weight(1f)) { onDigit("7") }
                CalcButton("8", Modifier.weight(1f)) { onDigit("8") }
                CalcButton("9", Modifier.weight(1f)) { onDigit("9") }
                CalcButton("x", Modifier.weight(1f)) { onOperation(Operation.Multiply) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CalcButton("4", Modifier.weight(1f)) { onDigit("4") }
                CalcButton("5", Modifier.weight(1f)) { onDigit("5") }
                CalcButton("6", Modifier.weight(1f)) { onDigit("6") }
                CalcButton("-", Modifier.weight(1f)) { onOperation(Operation.Subtract) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CalcButton("1", Modifier.weight(1f)) { onDigit("1") }
                CalcButton("2", Modifier.weight(1f)) { onDigit("2") }
                CalcButton("3", Modifier.weight(1f)) { onDigit("3") }
                CalcButton("+", Modifier.weight(1f)) { onOperation(Operation.Add) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CalcButton("0", Modifier.weight(2f)) { onDigit("0") }
                CalcButton(".", Modifier.weight(1f)) { onDecimal() }
                CalcButton("=", Modifier.weight(1f)) { onEquals() }
            }
        }
    }
}
@Composable
fun CalcButton(
    //Button creator
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = modifier.height(70.dp),
        shape = MaterialTheme.shapes.medium,
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary
        )
    ) {
        Text(label, fontSize = 24.sp)
    }
}
