package com.example.moderncalculator

import android.os.Bundle
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.moderncalculator.ui.CalculatorScreen
import com.example.moderncalculator.ui.theme.ModernCalculatorTheme
//Main class for application execution
class MainActivity : ComponentActivity() {
    //uses viewModel to determine button locations and operations with continuous "rendering" on button clicking
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ModernCalculatorTheme {
                val viewModel: CalculatorViewModel = viewModel()
                val uiState by viewModel.uiState.collectAsState()

                CalculatorScreen(
                    state = uiState,
                    onDigit = viewModel::onDigit,
                    onDecimal = viewModel::onDecimal,
                    onOperation = viewModel::onOperation,
                    onEquals = viewModel::onEquals,
                    onClear = viewModel::onClear
                )
                }
            }
        }
    }