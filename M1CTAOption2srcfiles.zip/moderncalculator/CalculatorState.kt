package com.example.moderncalculator

data class CalculatorState(
    val display: String = "0",
    val operand: Double? = null,
    val pendingOperation: Operation? = null,
    val clearOnNextDigit: Boolean = false)

enum class Operation {
    Add, Subtract, Multiply, Divide
}
