package com.example.viewinggallery.data

data class GalleryImage(
    val id: String,
    val uri: String,
    val isLocal: Boolean = false
)