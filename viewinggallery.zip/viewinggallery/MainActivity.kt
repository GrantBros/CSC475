package com.example.viewinggallery

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import com.example.viewinggallery.data.ImageRepository
import com.example.viewinggallery.data.GalleryImage
import com.example.viewinggallery.interfaces.*
import com.example.viewinggallery.ui.theme.ViewingGalleryTheme
import com.example.viewinggallery.viewmodel.GalleryViewModel


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ViewingGalleryTheme {
                val context = applicationContext

                val viewModel = remember {
                    GalleryViewModel(ImageRepository(context))
                }
                var selectedImage by remember {
                    mutableStateOf<GalleryImage?>(null)
                }

                LaunchedEffect(Unit) {
                    viewModel.loadImages()
                }

                StoragePermissionWrapper {
                    if (selectedImage == null) {
                        GalleryScreen(
                            images = viewModel.images,
                            useOnlineImages = viewModel.useOnlineImages,
                            onToggleSource = { viewModel.setImageSource(it) },
                            onImageClick = { selectedImage = it }
                        )
                    } else {
                        FullImageScreen(
                            image = selectedImage!!,
                            onExit = { selectedImage = null }
                        )
                    }
                }
            }
        }
    }
}