package com.example.viewinggallery.viewmodel

import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.viewinggallery.data.GalleryImage
import com.example.viewinggallery.data.ImageRepository

class GalleryViewModel(
    private val repository: ImageRepository
    ) : ViewModel() {
    var images by mutableStateOf<List<GalleryImage>>(emptyList())
        private set

    var useOnlineImages by mutableStateOf(true)
        private set

    fun loadImages() {
        images = try {
            if (useOnlineImages) {
                repository.loadOnlineImages()
            } else {
                repository.loadLocalImages()
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
        fun setImageSource(online: Boolean) {
        useOnlineImages = online
            loadImages()
        }
    }