package com.example.viewinggallery.interfaces

import android.Manifest
import android.os.Build
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import com.google.accompanist.permissions.*
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Alignment

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun StoragePermissionWrapper(
    content: @Composable () -> Unit
) {
    val permission = if (Build.VERSION.SDK_INT >= 33) {
        Manifest.permission.READ_MEDIA_IMAGES
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }
    val permissionState = rememberPermissionState(permission)

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        when {
            permissionState.status.isGranted -> {
                content()
            }

            permissionState.status.shouldShowRationale -> {
                Text("Permission is required to show your images.")
            }

            else -> {
                Button(onClick = { permissionState.launchPermissionRequest() }) {
                    Text("Grant Permission")
                }
            }
        }
    }
}


